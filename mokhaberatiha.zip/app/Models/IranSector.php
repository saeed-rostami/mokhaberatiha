<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranSector as BaseModel;

/**
 * Class IranSector (Bakhsh)
 */
class IranSector extends BaseModel
{

}
