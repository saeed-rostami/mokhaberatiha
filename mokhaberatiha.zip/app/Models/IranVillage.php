<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranVillage as BaseModel;

/**
 * Class IranVillage (Abadi)
 */
class IranVillage extends BaseModel
{

}
