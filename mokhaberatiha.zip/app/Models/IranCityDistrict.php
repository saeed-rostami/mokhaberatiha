<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranCityDistrict as BaseModel;

/**
 * Class IranCityDistrict (Mantaghe Shahri)
 */
class IranCityDistrict extends BaseModel
{

}
