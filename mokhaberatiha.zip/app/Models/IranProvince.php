<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranProvince as BaseModel;

/**
 * Class IranProvince (Ostan)
 */
class IranProvince extends BaseModel
{

}
