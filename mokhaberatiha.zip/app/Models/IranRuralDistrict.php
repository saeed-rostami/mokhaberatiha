<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranRuralDistrict as BaseModel;

/**
 * Class IranRuralDistrict (Dehestan)
 */
class IranRuralDistrict extends BaseModel
{

}
