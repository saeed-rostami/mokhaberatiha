<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranCity as BaseModel;

/**
 * Class IranCity (Shahr)
 */
class IranCity extends BaseModel
{

}
