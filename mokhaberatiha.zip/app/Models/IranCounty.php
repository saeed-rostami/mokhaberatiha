<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranCounty as BaseModel;

/**
 * Class IranCounty (Shahrestan)
 */
class IranCounty extends BaseModel
{

}
