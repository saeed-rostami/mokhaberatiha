<?php

namespace App\Models;

use SaliBhdr\TyphoonIranCities\Models\IranRegion as BaseModel;

/**
 * Class IranRegion (all regions/ Manategh)
 */
class IranRegion extends BaseModel
{

}
