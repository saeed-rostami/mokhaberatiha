<html>

<head>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="top-bar">
        <div class="container-fluid">
            <div class="col-md-6">
                <div class="">
                    <img style="width: 10%;" src="img/logo2.png" alt="logo">
                </div>
                {{-- <div class="search-btn">
                    <span><i class="fa fa-search"></i></span>
                </div> --}}
            </div>
            <div class="col-md-6">
                <div class="top-cat-box">
                    <div class="col-md-12">
                        <div class="menu">
                            <ul>
                                <li>{{ \Morilog\Jalali\Jalalian::now() }}
                                </li>
                            </ul>
                        </div>
                    </div>
                    <!-- <div class="col-md-3">
                     <div class="show-cat">
                         <span>
                             دسته ها
                             <i class="fa fa-bars"></i>
                         </span>
                     </div>
                     </div> -->
                </div>
            </div>
        </div>
    </div>
    <div class="main-header">
        <div class="container-fluid">
            <div class="col-md-10">
                <div class="main-menu">
                    <ul>
                        <li><a href="#">اتاق خبر</a></li>
                        <li><a href="#">انجمن ها</a></li>
                        <li><a href="#">قوانین و بخشنامه ها</a></li>
                        <li><a href="#">عضویت</a></li>
                        <li><a href="#">تماس با ما</a></li>
                        <li><a href="#">درباره ما</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-2">
                <div class="social-box">
                    <ul>
                        <li><a href="#">ورود</a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="clear-fix"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <div class="top-sidebar-r">
                    <span class="title">عکس</span>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/696112501123546.jpg" alt="">
                                        <figcaption><span>1</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="meta">
                                    <h5>
                                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و...</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 26</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/1733753707Capture.png" alt="">
                                        <figcaption><span>2</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="meta">
                                    <h5>
                                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و... متن ارسال شده</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 26</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/290667058azer news.jpg" alt="">
                                        <figcaption><span>3</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="meta">
                                    <h5>
                                        عنوان برایلورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده
                                        از طراحان گرافیک است. چاپگرها و... شده</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 26</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/parsitarh-1038x515.png" alt="">
                                        <figcaption><span>4</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="meta">
                                    <h5>
                                        عنوان برای متن ارسال شده</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 246</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="main-slider-box">
                    <div class="owl-carousel owl-theme main-slider">
                        <div class="item">
                            <figure>
                                <img src="img/unnamed.jpg" alt="">
                                <figcaption class="gradient-fig"></figcaption>
                                <figcaption class="desc-fig">
                                    <span><i class="fa fa-heart"></i> 56</span>
                                    <h3>عنوان خبری در اسلایدر</h3>
                                    <span><i class="fa fa-clock-o"></i> 10 ماه پیش</span>
                                    <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و...
                                    </p>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="item">
                            <figure>
                                <img src="img/290667058azer news.jpg" alt="">
                                <figcaption class="gradient-fig"></figcaption>
                                <figcaption class="desc-fig">
                                    <span><i class="fa fa-heart"></i> 56</span>
                                    <h3>عنوان خبری در اسلایدر</h3>
                                    <span><i class="fa fa-clock-o"></i> 10 ماه پیش</span>
                                    <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و...
                                    </p>
                                </figcaption>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="top-sidebar-l">
                    <span class="title">یادداشت</span>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 56</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 78</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 321</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 56</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 56</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="clear-fix"></div>
    {{-- <div class="main-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-3">
                    <div class="r-sidebar">
                        <div class="special-posts">
                            <span class="title">گفتگو</span><br>
                            <div class="special-box">
                                <a href="#">
                                    <figure>
                                        <img src="img/1397022612335447514155694.jpg" alt="">
                                        <figcaption class="txt">
                                            <h4>عنوان مطلب ارسالی</h4>
                                            <span><i class="fa fa-calendar-o"></i> 99/3/20</span>
                                            <span><i class="fa fa-comment-o"></i> 98</span>
                                        </figcaption>
                                        <figcaption class="link"><i class="fa fa-external-link"></i></figcaption>
                                    </figure>
                                </a>
                            </div>
                            <div class="special-box">
                                <a href="#">
                                    <figure>
                                        <img src="img/unnamed.jpg" alt="">
                                        <figcaption class="txt">
                                            <h4>که لازم است و برای شرایط فعلی تکنولوژی مور</h4>
                                            <span><i class="fa fa-calendar-o"></i> 99/3/20</span>
                                            <span><i class="fa fa-comment-o"></i> 98</span>
                                        </figcaption>
                                        <figcaption class="link"><i class="fa fa-external-link"></i></figcaption>
                                    </figure>
                                </a>
                            </div>
                            <div class="special-box">
                                <a href="#">
                                    <figure>
                                        <img src="img/696112501123546.jpg" alt="">
                                        <figcaption class="txt">
                                            <h4>لازمه توجه به نشریات در اینترنت</h4>
                                            <span><i class="fa fa-calendar-o"></i> 99/3/20</span>
                                            <span><i class="fa fa-comment-o"></i> 98</span>
                                        </figcaption>
                                        <figcaption class="link"><i class="fa fa-external-link"></i></figcaption>
                                    </figure>
                                </a>
                            </div>
                            <div class="special-box">
                                <a href="#">
                                    <figure>
                                        <img src="img/parsitarh-1038x515.png" alt="">
                                        <figcaption class="txt">
                                            <h4>یک عنوان برای این بخش نظر بگیرید ، این عنوا اگر بسیار بلند هم باشد توسط
                                                خود قالب بهینه خواهد شد
                                            </h4>
                                            <span><i class="fa fa-calendar-o"></i> 99/3/20</span>
                                            <span><i class="fa fa-comment-o"></i> 98</span>
                                        </figcaption>
                                        <figcaption class="link"><i class="fa fa-external-link"></i></figcaption>
                                    </figure>
                                </a>
                            </div>
                        </div>
                        <div class="ads-box">
                            <span class="title">تبلیغات</span><br>
                            <figure>
                                <img src="img/unnamed.jpg" alt="">
                            </figure>
                            <figure>
                                <img src="img/696112501123546.jpg" alt="">
                            </figure>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="content-wrapper">
                        <div class="most-views">
                            <span class="title">مطالب پربازدید</span>
                            <div class="col-md-8">
                                <div class="main-post">
                                    <a href="#">
                                        <figure>
                                            <img src="img/290667058azer news.jpg" alt="">
                                            <figcaption>
                                                <span><i class="fa fa-folder-o"></i> خبر روز</span>
                                                <h3>ایپسوم متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت</h3>
                                                <span><i class="fa fa-comments-o"></i> 65</span>
                                            </figcaption>
                                        </figure>
                                        <div class="p-div">
                                            <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از
                                                طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و
                                                سطرآنچنان که
                                                لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و...
                                            </p>
                                        </div>
                                </div>
                                </a>
                            </div>
                            <div class="col-md-4">
                                <div class="oth-posts">
                                    <div class="r-box">
                                        <span class="cat-span">آموزشی</span>
                                        <span class="cat-span">#خبر</span>
                                        <a href="#">
                                            <h5>که لازم است و برای شرایط فعلی تکنولوژی مور</h5>
                                        </a>
                                        <span><i class="fa fa-clock-o"></i> 3 دی 98</span>
                                    </div>
                                    <div class="r-box">
                                        <span class="cat-span">آموزشی</span>
                                        <span class="cat-span">#خبر</span>
                                        <a href="#">
                                            <h5>که لازم است و برای شرایط فعلی تکنولوژی مور</h5>
                                        </a>
                                        <span><i class="fa fa-clock-o"></i> 3 دی 98</span>
                                    </div>
                                    <div class="r-box">
                                        <span class="cat-span">آموزشی</span>
                                        <span class="cat-span">#خبر</span>
                                        <a href="#">
                                            <h5>که لازم است و برای شرایط فعلی تکنولوژی مور</h5>
                                        </a>
                                        <span><i class="fa fa-clock-o"></i> 3 دی 98</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="special-cat-box">
                            <span class="title">فیلم و ویدئو</span>
                            <div class="col-md-6">
                                <div class="main-post">
                                    <a href="#">
                                        <figure>
                                            <img src="img/290667058azer news.jpg" alt="">
                                            <figcaption>
                                                <span><i class="fa fa-folder-o"></i> خبر روز</span>
                                                <h3>ایپسوم متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت</h3>
                                                <span><i class="fa fa-comments-o"></i> 65</span>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                                <div class="main-post">
                                    <a href="#">
                                        <figure>
                                            <img src="img/696112501123546.jpg" alt="">
                                            <figcaption>
                                                <span><i class="fa fa-folder-o"></i> خبر روز</span>
                                                <h3>ایپسوم متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت</h3>
                                                <span><i class="fa fa-comments-o"></i> 65</span>
                                            </figcaption>
                                        </figure>
                                    </a>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="left-content">
                                    <div class="col-md-6">
                                        <a href="#">
                                            <div class="content">
                                                <figure>
                                                    <img src="img/696112501123546.jpg" alt="">
                                                    <figcaption><i class="fa fa-external-link"></i></figcaption>
                                                </figure>
                                                <span>آموزشی</span>
                                                <span>انجمن</span>
                                                <h5> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت</h5>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-6">
                                        <a href="#">
                                            <div class="content">
                                                <figure>
                                                    <img src="img/parsitarh-1038x515.png" alt="">
                                                    <figcaption><i class="fa fa-external-link"></i></figcaption>
                                                </figure>
                                                <span>آموزشی</span>
                                                <h5> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت</h5>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-6">
                                        <a href="#">
                                            <div class="content">
                                                <figure>
                                                    <img src="img/karkhaneh_iran_3.jpg" alt="">
                                                    <figcaption><i class="fa fa-external-link"></i></figcaption>
                                                </figure>
                                                <span>آموزشی</span>
                                                <h5> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت</h5>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="col-md-6">
                                        <a href="#">
                                            <div class="content">
                                                <figure>
                                                    <img src="img/1397022612335447514155694.jpg" alt="">
                                                    <figcaption><i class="fa fa-external-link"></i></figcaption>
                                                </figure>
                                                <span>آموزشی</span>
                                                <h5> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت</h5>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="l-sidebar">
                        <div class="cat-sidebar report">
                            <span class="title">گزارش</span>
                            <div class="text-left"><i class="fa fa-arrows-alt"></i></div>
                            <ul>
                                <li><a href="#">لورم ایپسو استفاده از طراحان</a></li>
                                <li><a href="#">و سه درصد می طلبد تا با نرم افزارها ش</a></li>
                                <li><a href="#"> فارسی ایجاد کرد. در ارائه راهکارها</a></li>
                                <li><a href="#"> اصلی و جوابگوی مورد استفاده قرار گیرد.</a></li>
                                <li><a href="#">متن ساختگی با تولید سادگی نامفهوم متن ساختگی با تولید سادگی
                                        نامفهوم
                                        استفاده استفاده</a>
                                </li>
                                <li><a href="#"> و سه درصد گذشته با نرم افزارها </a></li>
                                <li><a href="#">لورم ایپسو استفاده از طراحان</a></li>
                                <li><a href="#">و سه درصد می طلبد تا با نرم افزارها ش</a></li>
                                <li><a href="#"> فارسی ایجاد کرد. در ارائه راهکارها</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="l-sidebar">
                        <div class="cat-sidebar">
                            <span class="title">دسته بندی مطالب</span>
                            <div class="text-left"><i class="fa fa-folder-o"></i></div>
                            <ul>
                                <li><a href="#">موضوعی</a><span>32</span></li>
                                <li><a href="#">اخبار</a><span>322</span></li>
                                <li><a href="#">انجمن</a><span>2</span></li>
                                <li><a href="#">اتاق خبر</a><span>32</span></li>
                                <li><a href="#">دسته بندی نشده</a><span>52</span></li>
                                <li><a href="#">تستی</a><span>89</span></li>
                                <li><a href="#">خبر روز</a><span>30</span></li>
                                <li><a href="#">انجمن</a><span>74</span></li>
                                <li><a href="#">اتاق خبر</a><span>65</span></li>
                                <li><a href="#">دسته بندی نشده</a><span>81</span></li>
                                <li><a href="#">تستی</a><span>72</span></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear-fix"></div>
        {{-- <div class="latest-posts">
            <div class="container-fluid">
                <div class="blog-title-span">
                    <span class="title">آخرین مطالب</span>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/290667058azer news.jpg" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>بخش ویژه</span>
                                    <span>انجمن</span>
                                    <span>اتاق خبر</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/unnamed.jpg" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>مجلات</span>
                                    <span>انجمن</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/parsitarh-1038x515.png" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>بخش ویژه</span>
                                    <span>هفتگی</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/290667058azer news.jpg" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>بخش ویژه</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/1397022612335447514155694.jpg" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>ماه نامه</span>
                                    <span>گزارش</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/1397022612335447514155694.jpg" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>ویدئویی</span>
                                    <span>تصویری</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/290667058azer news.jpg" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>بخش ویژه</span>
                                    <span>انجمن</span>
                                    <span>اتاق خبر</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="post-box">
                        <a href="#">
                            <figure>
                                <img src="img/unnamed.jpg" alt="">
                                <figcaption class="meta-fig">
                                    <span><i class="fa fa-clock-o"></i> 99/3/20</span>&nbsp;
                                    <span><i class="fa fa-comment-o"></i> 12</span>
                                </figcaption>
                                <figcaption class="view">
                                    <span>مجلات</span>
                                    <span>انجمن</span>
                                </figcaption>
                            </figure>
                            <div class="text-p">
                                <h5>چگونه از اشخاص مطالبی که دوست نداریم دوری کنیم ؟</h5>
                                <p> متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی
                                    نامفهوم تولید سادگی از صنعت
                                </p>
                                <div class="text-rigt">
                                    <a href="#">ادامه ...</a>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div> --}}
    </div>
    <div class="clear-fix"></div>
    <div class="footer">
        <div class="container-fluid">
            <div class="col-md-5">
                <div class="footer-box">
                    <span class="title">مجله مخابراتی ها</span>
                    <p>متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید
                        سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی از
                        صنعت متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم
                        تولید سادگی از صنعت متن ساختگی بام تولید سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید
                        سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن سادگی نامفهوم تولید
                        سادگی از صنعت
                    </p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="footer-box">
                    <span class="title">دسترسی سریع</span>
                    <ul>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">قوانین</a></li>
                        <li><a href="#">نشریات</a></li>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">خبرنامه</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-2">
                <div class="footer-box">
                    <span class="title">موضوعی</span>
                    <ul>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">قوانین</a></li>
                        <li><a href="#">نشریات</a></li>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">خبرنامه</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-box contact-box">
                    <span class="title">تماس با ما</span>
                    <p><i class="fa fa-phone"></i> 09332187732</p>
                    <p><i class="fa fa-phone"></i> 09118395667</p>
                    <p><i class="fa fa-envelope-o"></i> info@مخابراتی ها.ir</p>
                    <p><i class="fa fa-map-marker"></i> رشت </p>
                </div>
            </div>
            <div class="clear-fix"></div>
        </div>
    </div>
    <div class="end-wrapper">
        <div class="container-fluid">
            <div class="col-md-6">
                <div class="copy-r">
                    <p>&copy; تمامی حقوق متعلق به مخابراتی ها می باشد</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="creator text-left">
                    <p>طراحی سایت: شرکت <a href="https://keytotec.com/">بخت آزما</a></p>
                </div>
            </div>
        </div>
    </div>
    <div class="bg"></div>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/index.js"></script>
</body>

</html>
