<a href="{{ route('note.index') }}">GO BACK</a>
<div>
    <h1>{{ $note->note }}</h1>
</div>
