<div>
    <form action="<?php echo e(route('note.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <textarea name="note" id="note" cols="30" rows="10" placeholder="متن اطلاعیه را وارد نمایید"></textarea>
        <button type="submit">ثبت اطلاعیه</button>
    </form>
</div>
<?php /**PATH F:\projects\laravel\mokhaberatiha\resources\views/note/create.blade.php ENDPATH**/ ?>