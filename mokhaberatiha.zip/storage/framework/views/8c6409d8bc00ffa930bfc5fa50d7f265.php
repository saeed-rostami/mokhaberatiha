<div>
    <a href="<?php echo e(route('note.create')); ?>">Add New Note</a>
    <hr>
</div>
<div>
    <?php $__currentLoopData = $notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <a href="<?php echo e(route('note.show', $note)); ?>">View</a>
            <a href="<?php echo e(route('note.edit', $note)); ?>">Edit</a>
            <form action="<?php echo e(route('note.destroy', $note)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" onclick="return confirm('are you sure?');">delete</button>
            </form>
        </div>
        <?php echo e(Str::words($note->note, 30)); ?>

        <hr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php echo e($notes->links()); ?>

</div>
<?php /**PATH D:\projects\laravel\mokhaberatiha\resources\views/note/index.blade.php ENDPATH**/ ?>