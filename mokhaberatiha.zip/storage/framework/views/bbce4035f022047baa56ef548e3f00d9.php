<div>
    <form action="<?php echo e(route('note.update', $note)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <textarea name="note" id="note" cols="30" rows="10"><?php echo e($note->note); ?></textarea>
        <button type="submit">update</button>
    </form>
</div>
<?php /**PATH D:\projects\laravel\mokhaberatiha\resources\views/note/edit.blade.php ENDPATH**/ ?>