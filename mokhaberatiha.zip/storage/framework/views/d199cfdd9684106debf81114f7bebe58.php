<a href="<?php echo e(route('note.index')); ?>">GO BACK</a>
<div>
    <h1> note added </h1>
    <?php if(session()->has('message')): ?>
        <small>
            <?php echo e(session()->get('message')); ?>

        </small>
    <?php endif; ?>
    <h1><?php echo e($note->note); ?></h1>
</div>
<?php /**PATH F:\projects\laravel\mokhaberatiha\resources\views/note/show.blade.php ENDPATH**/ ?>