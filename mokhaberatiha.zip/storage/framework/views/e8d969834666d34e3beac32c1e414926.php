<html>

<head>
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/font-awesome.min.css">
    <link rel="stylesheet" href="css/owl.carousel.css">
    <link rel="stylesheet" href="css/owl.theme.default.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="top-bar">
        <div class="container-fluid">
            <div class="col-md-6">
                <div class="">
                    <img style="width: 10%;" src="img/logo2.png" alt="logo">
                </div>
                
            </div>
            <div class="col-md-6">
                <div class="top-cat-box">
                    <div class="col-md-12">
                        <div class="menu">
                            <ul>
                                <li><?php echo e(\Morilog\Jalali\Jalalian::now()); ?>

                                </li>


                            </ul>
                        </div>
                    </div>
                    <!-- <div class="col-md-3">
                     <div class="show-cat">
                         <span>
                             دسته ها
                             <i class="fa fa-bars"></i>
                         </span>
                     </div>
                     </div> -->
                </div>
            </div>
        </div>
    </div>
    <div class="main-header">
        <div class="container-fluid">
            <div class="col-md-10">
                <div class="main-menu">
                    <ul>
                        <li><a href="#">اتاق خبر</a></li>
                        <li><a href="#">انجمن ها</a></li>
                        <li><a href="#">قوانین و بخشنامه ها</a></li>
                        <li><a href="#">عضویت</a></li>
                        <li><a href="#">تماس با ما</a></li>
                        <li><a href="#">درباره ما</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-2">
                <div class="social-box">
                    <ul>
                        <li><a href="#">ورود</a></li>

                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div class="clear-fix"></div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3">
                <div class="top-sidebar-r">
                    <span class="title">عکس</span>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/696112501123546.jpg" alt="">
                                        <figcaption><span>1</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="meta">
                                    <h5>
                                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و...</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 26</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/1733753707Capture.png" alt="">
                                        <figcaption><span>2</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="meta">
                                    <h5>
                                        لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و... متن ارسال شده</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 26</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/290667058azer news.jpg" alt="">
                                        <figcaption><span>3</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="meta">
                                    <h5>
                                        عنوان برایلورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده
                                        از طراحان گرافیک است. چاپگرها و... شده</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 26</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-6">
                                <div class="img-box">
                                    <figure>
                                        <img src="img/parsitarh-1038x515.png" alt="">
                                        <figcaption><span>4</span></figcaption>
                                    </figure>
                                </div>
                            </div>
                            <div class="col-md-6 ">
                                <div class="meta">
                                    <h5>
                                        عنوان برای متن ارسال شده</h6>
                                        <span><i class="fa fa-clock-o"></i> 99/3/20</span>
                                        <div class="text-left">
                                            <sub><i class="fa fa-comment"></i> 246</sub>
                                        </div>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="main-slider-box">
                    <div class="owl-carousel owl-theme main-slider">
                        <div class="item">
                            <figure>
                                <img src="img/unnamed.jpg" alt="">
                                <figcaption class="gradient-fig"></figcaption>
                                <figcaption class="desc-fig">
                                    <span><i class="fa fa-heart"></i> 56</span>
                                    <h3>عنوان خبری در اسلایدر</h3>
                                    <span><i class="fa fa-clock-o"></i> 10 ماه پیش</span>
                                    <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و...
                                    </p>
                                </figcaption>
                            </figure>
                        </div>
                        <div class="item">
                            <figure>
                                <img src="img/290667058azer news.jpg" alt="">
                                <figcaption class="gradient-fig"></figcaption>
                                <figcaption class="desc-fig">
                                    <span><i class="fa fa-heart"></i> 56</span>
                                    <h3>عنوان خبری در اسلایدر</h3>
                                    <span><i class="fa fa-clock-o"></i> 10 ماه پیش</span>
                                    <p>لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                        گرافیک است. چاپگرها و...
                                    </p>
                                </figcaption>
                            </figure>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="top-sidebar-l">
                    <span class="title">یادداشت</span>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 56</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 78</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 321</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 56</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                    <a href="#">
                        <div class="bx">
                            <div class="col-md-3 nopadding">
                                <span><i class="fa fa-heart"></i> 56</span>
                            </div>
                            <div class="col-md-8 nopadding">
                                <h3>رم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان
                                    گرافیک
                                    است. چاپگرها و متو
                                </h3>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="clear-fix"></div>
    
    </div>
    <div class="clear-fix"></div>
    <div class="footer">
        <div class="container-fluid">
            <div class="col-md-5">
                <div class="footer-box">
                    <span class="title">مجله مخابراتی ها</span>
                    <p>متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید
                        سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی از
                        صنعت متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم
                        تولید سادگی از صنعت متن ساختگی بام تولید سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید
                        سادگی از صنعت متن ساختگی با تولید سادگی نامفهوم تولید سادگی از صنعت متن سادگی نامفهوم تولید
                        سادگی از صنعت
                    </p>
                </div>
            </div>
            <div class="col-md-2">
                <div class="footer-box">
                    <span class="title">دسترسی سریع</span>
                    <ul>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">قوانین</a></li>
                        <li><a href="#">نشریات</a></li>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">خبرنامه</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-2">
                <div class="footer-box">
                    <span class="title">موضوعی</span>
                    <ul>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">قوانین</a></li>
                        <li><a href="#">نشریات</a></li>
                        <li><a href="#">موضوعی</a></li>
                        <li><a href="#">خبرنامه</a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3">
                <div class="footer-box contact-box">
                    <span class="title">تماس با ما</span>
                    <p><i class="fa fa-phone"></i> 09332187732</p>
                    <p><i class="fa fa-phone"></i> 09118395667</p>
                    <p><i class="fa fa-envelope-o"></i> info@مخابراتی ها.ir</p>
                    <p><i class="fa fa-map-marker"></i> رشت </p>
                </div>
            </div>
            <div class="clear-fix"></div>
        </div>
    </div>
    <div class="end-wrapper">
        <div class="container-fluid">
            <div class="col-md-6">
                <div class="copy-r">
                    <p>&copy; تمامی حقوق متعلق به مخابراتی ها می باشد</p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="creator text-left">
                    <p>طراحی سایت: شرکت <a href="https://keytotec.com/">بخت آزما</a></p>
                </div>
            </div>
        </div>
    </div>
    <div class="bg"></div>
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/index.js"></script>
</body>

</html>
<?php /**PATH D:\projects\laravel\mokhaberatiha\resources\views/website/index.blade.php ENDPATH**/ ?>