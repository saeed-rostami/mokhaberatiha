<a href="<?php echo e(route('note.index')); ?>">GO BACK</a>
<div>
    <h1><?php echo e($note->note); ?></h1>
</div>
<?php /**PATH D:\projects\laravel\mokhaberatiha\resources\views/note/show.blade.php ENDPATH**/ ?>